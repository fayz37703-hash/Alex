package com.alex.assistant

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone as CPhone
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** كل أوامر التلفون. النص يصل مطبّعاً (بدون تشكيل، ة=ه، ى=ي، أ=ا) */
class PhoneControl(private val c: Context, private val say: (String) -> Unit) {
    private val pm = c.packageManager
    private val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val aliases = mapOf(
        "تيك توك" to "tiktok", "تيكتوك" to "tiktok", "يوتيوب" to "youtube", "واتساب" to "whatsapp", "واتس" to "whatsapp",
        "فيسبوك" to "facebook", "انستقرام" to "instagram", "انستجرام" to "instagram", "سناب" to "snapchat",
        "تلقرام" to "telegram", "تليجرام" to "telegram", "كروم" to "chrome", "تويتر" to "twitter",
        "نتفلكس" to "netflix", "سبوتيفاي" to "spotify", "جيميل" to "gmail", "زوم" to "zoom", "اعدادات" to "settings", "قوقل" to "google", "جوجل" to "google"
    )
    // أسماء التطبيقات الأساسية: تُفتح بفئة النظام بدل الاسم
    private val cats = listOf(
        listOf("معرض", "الصور", "البوم") to Intent.CATEGORY_APP_GALLERY,
        listOf("حاسبه", "الحاسبه") to Intent.CATEGORY_APP_CALCULATOR,
        listOf("تقويم") to Intent.CATEGORY_APP_CALENDAR,
        listOf("جهات الاتصال", "جهات") to Intent.CATEGORY_APP_CONTACTS,
        listOf("ايميل", "بريد") to Intent.CATEGORY_APP_EMAIL,
        listOf("متصفح") to Intent.CATEGORY_APP_BROWSER,
        listOf("موسيق") to Intent.CATEGORY_APP_MUSIC,
        listOf("خرائط") to Intent.CATEGORY_APP_MAPS,
        listOf("رسائل") to Intent.CATEGORY_APP_MESSAGING
    )
    private val nums = mapOf("واحد" to 1, "واحده" to 1, "اثنين" to 2, "اتنين" to 2, "ثلاثه" to 3, "تلاته" to 3,
        "اربعه" to 4, "خمسه" to 5, "خمس" to 5, "سته" to 6, "سبعه" to 7, "ثمانيه" to 8, "تمانيه" to 8, "تسعه" to 9,
        "عشره" to 10, "عشر" to 10, "احدعش" to 11, "اثنعش" to 12, "عشرين" to 20, "ثلاثين" to 30, "اربعين" to 40,
        "خمسين" to 50, "ستين" to 60)

    private fun num(s: String): Int {
        Regex("\\d+").find(s)?.let { return it.value.toInt() }
        return s.split(" ").fold(0) { a, w -> a + (nums[w] ?: nums[w.drop(1)] ?: 0) }
    }

    fun run(cmd: String) {
        fun has(vararg k: String) = k.any { it in cmd }
        val off = has("اطفي", "اقفل", "طفي", "وقف", "سكر")
        when {
            has("وقف الاغني", "وقف الموسيق", "بوز") -> media(KeyEvent.KEYCODE_MEDIA_PAUSE)
            has("شغل الموسيق", "شغل اغني", "كمل الاغني") -> media(KeyEvent.KEYCODE_MEDIA_PLAY)
            has("الاغنيه الجايه", "غير الاغنيه", "التالي") -> media(KeyEvent.KEYCODE_MEDIA_NEXT)
            has("السابق", "الاغنيه الي قبل") -> media(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            has("كشاف", "فلاش") -> torch(!off)
            has("ارفع الصوت", "علي الصوت", "زود الصوت") -> vol(AudioManager.ADJUST_RAISE)
            has("اخفض الصوت", "وطي الصوت", "قلل الصوت", "خفف الصوت") -> vol(AudioManager.ADJUST_LOWER)
            has("اكتم", "كتم الصوت", "صامت") -> vol(AudioManager.ADJUST_MUTE)
            has("الساعه كم", "كم الساعه", "الوقت") -> say("الساعة " + SimpleDateFormat("h:mm a", Locale("ar")).format(Date()))
            has("التاريخ", "اي يوم", "اليوم كم") -> say(SimpleDateFormat("EEEE d MMMM", Locale("ar")).format(Date()))
            has("بطاريه") && has("كم", "نسبه", "فيها") -> {
                val b = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                say("البطارية ${b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} بالمئة")
            }
            has("منبه") -> alarm(cmd)
            has("مؤقت", "تايمر") -> timer(cmd)
            cmd.startsWith("اتصل") -> call(cmd.removePrefix("اتصل").trim().removePrefix("ب").trim())
            has("واتس") && Regex("(محادثه|دردشه|شات|كلم|ارسل|ابعت|رساله)").containsMatchIn(cmd) -> whatsapp(cmd)
            Regex("(ابحث|دور علي)").containsMatchIn(cmd) -> search(cmd)
            Regex("^(وديني|خذني)").containsMatchIn(cmd) ->
                go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(cmd.replace(Regex("^(وديني|خذني)( الي| ل)?"), "").trim()))))
            has("الرئيسيه", "شاشه البيت") -> go(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
            has("واي فاي", "وايفاي") -> go(Intent(Settings.ACTION_WIFI_SETTINGS))
            has("بلوتوث") -> go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            has("طيران") -> go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
            has("الموقع") -> go(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            has("هوتسبوت", "نقطه اتصال", "بيانات الجوال") -> go(Intent(Settings.ACTION_WIRELESS_SETTINGS))
            has("اعدادات الشاشه", "السطوع") -> go(Intent(Settings.ACTION_DISPLAY_SETTINGS))
            has("اعدادات الصوت") -> go(Intent(Settings.ACTION_SOUND_SETTINGS))
            has("توفير الطاقه", "اعدادات البطاريه") -> go(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
            has("nfc", "ان اف سي") -> go(Intent(Settings.ACTION_NFC_SETTINGS))
            else -> {
                val p = listOf("افتح", "شغل", "روح الي", "روح ل").firstOrNull { cmd.startsWith(it) }
                if (p != null) openApp(cmd.removePrefix(p).trim()) else say("ما فهمت")
            }
        }
    }

    private fun openApp(raw: String) {
        if (raw.contains("كاميرا")) {
            go(Intent(if (raw.contains("فيديو")) MediaStore.ACTION_VIDEO_CAPTURE else MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); return
        }
        cats.firstOrNull { (names, _) -> names.any { raw.contains(it) } }?.let { (_, cat) ->
            go(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, cat)); return
        }
        val name = raw.removePrefix("ال").trim()
        val key = aliases[name] ?: aliases[raw] ?: name
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(main, 0).firstOrNull {
            val l = norm(it.loadLabel(pm).toString()); l.contains(key) || key.contains(l)
        }
        val i = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (i != null) go(i) else say("ما لقيت $raw")
    }

    private fun go(i: Intent) {
        try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); say("حسناً") }
        catch (e: Exception) { say("ما قدرت أنفذ الأمر") }
    }

    private fun torch(on: Boolean) {
        val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return say("ما في كشاف")
        cm.setTorchMode(id, on); say("حسناً")
    }

    private fun vol(dir: Int) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI); say("حسناً") }

    private fun media(code: Int) {
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code)); say("حسناً")
    }

    private fun alarm(cmd: String) {
        var h = num(cmd)
        if (h == 0) return go(Intent(AlarmClock.ACTION_SHOW_ALARMS))
        if ((cmd.contains("مساء") || cmd.contains("العصر") || cmd.contains("ليل")) && h < 12) h += 12
        go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h % 24).putExtra(AlarmClock.EXTRA_MINUTES, 0)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }

    private fun timer(cmd: String) {
        val n = num(cmd).coerceAtLeast(1)
        val secs = if (cmd.contains("ثاني")) n else if (cmd.contains("ساعه")) n * 3600 else n * 60
        go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }

    private fun findNumber(who: String): String? {
        if (who.isBlank() || c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        c.contentResolver.query(CPhone.CONTENT_URI, arrayOf(CPhone.DISPLAY_NAME, CPhone.NUMBER), null, null, null)?.use {
            while (it.moveToNext()) if (norm(it.getString(0) ?: "").contains(who)) return it.getString(1)
        }
        return null
    }

    private fun call(who: String) {
        val digits = who.filter { it.isDigit() }
        if (digits.length >= 5) return go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")))
        val num = findNumber(who) ?: return say("ما لقيت $who في جهات الاتصال")
        go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))
    }

    private fun search(cmd: String) {
        val q = Regex("(?:ابحث|دور)(?:\\s+في)?(?:\\s+(?:قوقل|جوجل|الانترنت))?(?:\\s+(?:عن|علي))?\\s+(.+)$")
            .find(cmd)?.groupValues?.get(1)?.trim()
        if (q.isNullOrEmpty()) return say("ابحث عن ماذا؟")
        go(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
    }

    // "افتح واتساب وكلم احمد" / "ارسل لاحمد في واتساب قل له انا جاي"
    private fun whatsapp(cmd: String) {
        val msg = Regex("(?:قل له|قول له|قل لها|قول لها|بنص|رسالته|رسالتها)\\s+(.+)$").find(cmd)?.groupValues?.get(1)
        val head = if (msg != null) cmd.substring(0, cmd.indexOf(msg)) else cmd
        val stop = setOf("افتح", "شغل", "في", "علي", "ع", "و", "محادثه", "دردشه", "شات", "كلم", "ارسل", "ابعت", "رساله",
            "ل", "الي", "مع", "قل", "قول", "له", "لها", "بنص", "رسالته", "رسالتها")
        val name = head.split(" ").filter { it.isNotBlank() && it !in stop && !it.startsWith("واتس") && !it.startsWith("الواتس") }
            .joinToString(" ")
        if (name.isEmpty()) return openApp("واتساب")
        val num = findNumber(name) ?: findNumber(name.removePrefix("ل")) ?: return say("ما لقيت $name في جهات الاتصال")
        val uri = Uri.parse("https://wa.me/" + num.filter { it.isDigit() } + if (msg != null) "?text=" + Uri.encode(msg) else "")
        go(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[\u064B-\u0652]"), "")
        .replace(Regex("[أإآ]"), "ا").replace("ة", "ه").replace("ى", "ي")
}
