package com.alex.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class VoiceService : Service(), RecognitionListener {

    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val h = Handler(Looper.getMainLooper())
    private var running = true
    private var speaking = false
    private var warned = false
    private var awakeUntil = 0L

    // كلمات التنبيه بعد التطبيع. غيّرها لأي اسم تريده
    private val wakeWords = listOf("اليكسا", "اليكس", "اليكز", "اليكيس", "الكس", "alex")
    private val phone by lazy { PhoneControl(this, this::say) }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("alex", "أليكس", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "alex").setContentTitle("أليكس يستمع")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        tts = TextToSpeech(this) {
            tts?.language = Locale("ar")
            tts?.setPitch(0.8f)  // نبرة أعمق = إحساس روبوتي
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { speaking = true; h.post { sr?.cancel() } }
                override fun onDone(id: String?) { speaking = false; h.post { listen() } }
                override fun onError(id: String?) { speaking = false; h.post { listen() } }
            })
            h.post { listen() }
        }
    }

    private fun listen() {
        if (!running || speaking) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            if (!warned) { warned = true; say("خدمة التعرف على الصوت غير متوفرة. ثبّت تطبيق قوقل") }
            return
        }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        sr?.startListening(i)
    }

    private fun restart(delay: Long) { h.postDelayed({ listen() }, delay) }

    override fun onResults(b: Bundle?) {
        val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        handle(list)
        restart(300)
    }

    override fun onError(e: Int) {
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { running = false; stopSelf(); return }
        restart(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 700)
    }

    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(p: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(p: Bundle?) {}
    override fun onEvent(t: Int, p: Bundle?) {}

    private fun handle(list: List<String>) {
        val texts = list.map { normalize(it) }
        val t = texts.firstOrNull { s -> wakeWords.any { it in s } }
        if (t != null) {
            val w = wakeWords.first { it in t }
            val cmd = t.substringAfter(w).trim()
            if (cmd.isEmpty()) { awakeUntil = System.currentTimeMillis() + 8000; say("نعم") } else phone.run(cmd)
        } else if (System.currentTimeMillis() < awakeUntil && texts.isNotEmpty()) {
            awakeUntil = 0; phone.run(texts[0])
        }
    }

    private fun say(s: String) {
        tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "u")
        h.postDelayed({ if (speaking && tts?.isSpeaking != true) { speaking = false; listen() } }, 5000)
    }

    private fun normalize(s: String) = s.lowercase()
        .replace(Regex("[\u064B-\u0652]"), "")
        .replace(Regex("[أإآ]"), "ا").replace("ة", "ه").replace("ى", "ي")

    override fun onDestroy() {
        running = false; h.removeCallbacksAndMessages(null)
        sr?.destroy(); tts?.shutdown(); super.onDestroy()
    }
    override fun onBind(i: Intent?): IBinder? = null
}
