package com.alex.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(48, 48, 48, 48) }
        box.addView(TextView(this).apply { text = "أليكس"; textSize = 36f; gravity = Gravity.CENTER })
        box.addView(TextView(this).apply { text = "قل: يا أليكس افتح الكاميرا"; gravity = Gravity.CENTER })
        box.addView(Button(this).apply { text = "تشغيل"; setOnClickListener { start() } })
        box.addView(Button(this).apply { text = "إيقاف"; setOnClickListener { stopService(Intent(this@MainActivity, VoiceService::class.java)) } })
        setContentView(box)
    }

    private fun start() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        if (perms.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(perms.toTypedArray(), 1); return
        }
        if (!Settings.canDrawOverlays(this)) {  // يسمح بفتح التطبيقات من الخلفية
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        startForegroundService(Intent(this, VoiceService::class.java))
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) = start()
}
